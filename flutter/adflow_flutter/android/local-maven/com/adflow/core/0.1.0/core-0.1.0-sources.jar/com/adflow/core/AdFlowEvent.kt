package com.adflow.core

enum class AdFlowEvent {
    LOADING, LOADED, LOAD_FAILED, RETRYING, WATERFALL_NEXT,
    SHOWN, SHOW_BLOCKED, SHOW_FAILED, NO_FILL,
}
